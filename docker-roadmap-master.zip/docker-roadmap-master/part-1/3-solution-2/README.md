
 - Install Node.js
 - cd into folder
 - npm install
 - node index.js

## Solution
 - We use the alpine node image which is much more lightweight that the node image
