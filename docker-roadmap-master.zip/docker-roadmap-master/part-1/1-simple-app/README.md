
 - Install Node.js
 - cd into folder
 - npm install
 - node index.js
